const express = require("express");
const dotenv = require("dotenv");
const mongoose = require("mongoose");
const cookieParser = require("cookie-parser");
const app = express();




// db connection
// const DB = "mongodb+srv://love:love@cluster0.vhpdm.mongodb.net/myFirstDatabase?retryWrites=true&w=majority" 
// app.use(express.json());
dotenv.config({path:"./.env"});

require('./db/conn');
app.use(express.json());
app.use(cookieParser());
// const User = require("./model/userSchema");
app.use(require('./router/auth'));

const PORT = process.env.PORT || 5000;


// MIddleware
// const middleware = (req,res,next)=>{
//         console.log(`middleware`);
//         next();
// }


// app.get('/',(req,res)=>{
//     res.send(`Hello backend`);
// });

// app.get('/about',middleware,(req,res)=>{
//     console.log(`about`);
//     res.send(`Hello about`);
// });

// app.get('/contact',(req,res)=>{
//     // res.cookie("name","love");
//     res.send(`Hello contact`);
// });

app.get('/signin',(req,res)=>{
    res.send(`Hello signin`);
});

app.get('/signup',(req,res)=>{
    res.send(`Hello signup`);
});

// heroku deploy
if(process.env.NODE_ENV === "production"){
    app.use(express.static("client/build"));
    const path = require("path");
    app.get("*",(req,res)=>{
        res.sendFile(path.resolve(__dirname,"client","build","index.html"));
    })
}

app.listen(PORT,()=>{
    console.log(`Server is running on port ${PORT}`);
}
);