import React , {createContext,useReducer} from 'react';
import {initialState,reducer} from './reducer/UseReduer';
import Navbar from './components/Navbar';
import Contact from './components/Contact';
import About from './components/About';
import Signup from './components/Signup';
import Login from './components/Login';
import Home from './components/Home';
import 'bootstrap/dist/css/bootstrap.css';
import {BrowserRouter as Router,Switch,Route} from "react-router-dom";
import Errorpage from './components/Errorpage';
import Logout from './components/Logout';

export const userContext = createContext();
// 1.context api
const Routing = () =>{
  return (<Router>
  <Navbar   />
  <div className="container mt-3">
  <Switch>
        <Route exact path="/">
         <Home />
        </Route>
        <Route exact path="/contact">
          <Contact />
        </Route>
        <Route exact path="/about">
          <About />
        </Route>
        <Route exact path="/signup">
          <Signup /> 
        </Route>
        <Route exact path="/login">
          <Login /> 
        </Route>
        <Route exact path="/logout">
          <Logout />
        </Route>

        <Route >
          <Errorpage /> 
        </Route>
        
  </Switch>
  </div>
  </Router>)
}
 
const  App = () =>{


const [state,dispatch] = useReducer(reducer,initialState);
 

  return (
    <>
    <userContext.Provider value={{state,dispatch}}>
    <Routing />
    </userContext.Provider>
    </> 
  );
}

export default App;
