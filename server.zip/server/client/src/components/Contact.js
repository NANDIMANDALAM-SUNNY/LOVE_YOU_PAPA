import {React,useState,useEffect} from 'react';


const Contact = () => {
  const [userData,setUserData] = useState({
    name:'',
    email:'',
    phone:'',
    message:''
  });


 
  
  const userContact = async () =>{
    try{
      const res =await fetch('/getdata',{
          method:"GET",
          headers:{
            "Content-Type":"application/json"
          },
      });
      const data = await res.json();
      console.log(data);
      setUserData({...userData,name:data.name,email:data.email,phone:data.phone});

      if(!res.status===200){
        const error = new Error (res.error);
        throw error;
      }
    }catch(err){
      console.log(err);
     

    }
  }
useEffect(() => {
  userContact();
}, [])

// 
const handleInputs =(e)=>{
const name = e.target.name;
const value = e.target.value;
setUserData({...userData,[name]:value});
}

const contactForm = async (e)=>{
  e.preventDefault();
  const {name,email,phone,message} = userData;
  const res = fetch('/contact',{
    method:"POST",
    headers:{
      "Content-Type":"application/json"
    },
    body:JSON.stringify({name,email,phone,message})
  })
  const data = await res.json();
  // console.log(data);
  if( res.status == 201 ||!data){
    window.alert("Please fill all fields");
  }else{
    window.alert("Message sent");
    setUserData({...userData,message:""});
  }

}


  return (
    <>
    <form method='POST'>
    <div className="mb-3">
        <label htmlFor="name" for="exampleInputEmail1" className="form-label"><i class="zmdi zmdi-account-add zmdi-hc-2x"></i>Name</label>
         <input type="text" className="form-control" id="name" name="name" autoComplete="off" placeholder="Enter userName" value={userData.name} onChange={handleInputs} aria-describedby="emailHelp" />
        {/* <h3>username:{userData.name}</h3> */}
      </div>
       {/* email */}
      <div className="mb-3">
        <label htmlFor="email" for="exampleInputEmail1" className="form-label"><i class="zmdi zmdi-email zmdi-hc-2x"></i>Email</label>
         <input type="email" className="form-control" id="email" name="email" autoComplete="off" placeholder="Enter email"  value={userData.email} onChange={handleInputs} aria-describedby="emailHelp" />
         {/* <h3>Email:{userData.email}</h3> */}
       </div>
       {/* phone */}
       <div className="mb-3">
         <label htmlFor="phone" for="exampleInputEmail1" className="form-label"><i class="zmdi zmdi-phone-in-talk -add zmdi-hc-2x"></i>Phone</label>
         <input type="number" className="form-control" id="phone" name="phone" autoComplete="off" placeholder="Enter phone " value={userData.phone} onChange={handleInputs} aria-describedby="emailHelp" />
              {/* <h3>phone:{userData.phone}</h3> */}
                    </div>
          {/* textarea */}

          <div className="text-field">
            <textarea placeholder="Message" name="message" value={userData.message} onChange={handleInputs} rows="10" cols="160"></textarea>
          </div>

      <button type="submit" name="submit" id="submit" value="submit" onClick={contactForm} class="btn btn-primary">Submit</button>
      </form>
    </>
  )
}

export default Contact