const express = require("express");
const router = express.Router();
require('../db/conn');
const User = require("../model/userSchema");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const authenticate = require("../middleware/Authenticate");
// using promise
// router.get('/',(req,res)=>{
//     res.send(`Hello backend from router`);
// });

// router.post('/register',(req,res)=>{

//     const {name,email,phone,work,password,cpassword} = req.body;
//     if(!name || !email || !phone || !work || !password || !cpassword){
//         return res.status(422).json({error:"Fill all fields"})
//     // return res.json({error:"Fill all fields"});
//     }
//     User.findOne({email:email})
//         .then((userExist) => {
//             if(userExist){
//                 return res.status(422).json({error:"User already exist"})
//             }
//             const user = new User({name,email,phone,work,password,cpassword});

//             user.save().then(()=>{
//                 res.status(201).json({message:"User created successfully"});
//             }).catch((err)=>res.status(500).json({error:"failed to create user"}));
//         }).catch(err=>{console.log(err);})
    


//     // console.log(name)
//     // console.log(req.body);
//     // res.json({message:req.body});

// });


// using async await

router.get('/',async (req,res)=>{
    res.send(`Hello backend from router`);
});

router.post('/register',async (req,res)=>{

    const {name,email,phone,work,password,cpassword} = req.body;
    if(!name || !email || !phone || !work || !password || !cpassword){
        return res.status(422).json({error:"Fill all fields"})
    // return res.json({error:"Fill all fields"});
    }
    try{
        const userExist = await User.findOne({email:email})
        if(userExist){
            return res.status(422).json({error:"User already exist"})
        }else if(password !== cpassword){
            return res.status(422).json({error:"Password does not match"})
        }else{
            const user = new User({name,email,phone,work,password,cpassword});

            // hashning password
            await user.save();
            res.status(201).json({message:"User created successfully"});
        }
    
    }catch(err){
        console.log(err);

    }

    // console.log(name)
    // console.log(req.body);
    // res.json({message:req.body});

   });


//    login route
router.post('/signin',async (req,res)=>{
    // console.log(req.body);
    // res.json({message:"working"});
    // const {email,password} = req.body;

    try{
       const {email,password} = req.body;
       if(!email || !password){
           return res.status(400).json({error:"Fill all fields"})
       }
         const userLogin = await User.findOne({email:email});
            // console.log(userLogin);
            if(userLogin){
                const isMatch = await bcrypt.compare(password,userLogin.password);

                const token =await userLogin.generateAuthToken();
                // console.log(token);
                res.cookie('jwtoken',token,{
                    httpOnly:true,
                    expires:new Date(Date.now() + 3600000)
                });
                    if(!isMatch){
                        res.status(400).json({error:"Invalid credentials"});
                    }else{
                        res.status(200).json({message:"signin success"});
            }

            }else{
                res.status(400).json({error:"Invalid credentials"});
            }
            
            
    }catch(err){
        console.log(err);
    }
});



// about user
router.get('/about',authenticate,(req,res)=>{
    console.log(`about`);
    // res.send(`Hello about`);
    res.send(req.rootUser);
});

// get userdata
router.get('/getdata',authenticate,(req,res)=>{
    console.log(`Contact`);
    // res.send(`Hello about`);
    res.send(req.rootUser);
})
// contact us
router.post('/contact',authenticate, async(req,res)=>{
    try{
        const {name,email,phone,message} =req.body;
        if(!name || !email || !phone || !message){
            console.log("error in contact");
            return res.status(422).json({error:"Fill all contact fields"})
        }
        const userContact = await User.findOne({_id:req.rootUserId});

        if(userContact){
            const userMessage =await userContact.addMessage(name,email,phone,message);

            await userContact.save();
            res.status(201).json({message:"Message sent successfully"});
        }

    }catch(error){
        console.log(error);
    }
});



// logout

router.get('/logout',(req,res)=>{
    console.log(`logout`);
    // res.send(`Hello about`);
    res.clearCookie('jwtoken',{path:'/'})
    res.status(200).send(`userLogout`);
});
module.exports = router;