import {React,useState} from 'react';

import {Link, useHistory} from 'react-router-dom';
const Signup = () => {

  const history = useHistory();

  const [user, setUser] = useState({name:"",email:"",phone:"",work:"",password:"",cpassword:""})
  // handle inputs\
  let name,value;
  const handleInputs = (e) =>{
      console.log(e);
      name = e.target.name;
      value=e.target.value;

      setUser({...user,[name]:value});
}

const PostData = async (e) =>{
  e.preventDefault();

  const {name,email,phone,work,password,cpassword} = user;

  const res = await fetch("/register",{
    method:"POST",
    headers:{
      "Content-Type":"application/json"
    },
    body:JSON.stringify({
      name,email,phone,work,password,cpassword 
    })
  });
  const data = await res.json();
    if(res.status=== 422  || !data){
          window.alert("Failed");
          console.log("Failed");
    }else{
      window.alert("success");
      console.log("success");
      history.push("/login")
    }
}
  return (
    <>
    
      <section>
        <div className="mt-5">
          <div className="signup-content">
              <div className="signup-form">
                <h2 className = "form-title">Sign up</h2>
                <form method="POST">
                  {/* username */}
                    <div className="mb-3">
                      <label htmlFor="name" for="exampleInputEmail1" className="form-label"><i class="zmdi zmdi-account-add zmdi-hc-2x"></i>Username</label>
                      <input type="text" className="form-control" id="name" name="name" autoComplete="off"
                      value={user.name}
                      onChange={handleInputs}
                      placeholder="Enter userName" aria-describedby="emailHelp" />
                    </div>
                    {/* email */}
                    <div className="mb-3">
                      <label htmlFor="email" for="exampleInputEmail1" className="form-label"><i class="zmdi zmdi-email zmdi-hc-2x"></i>Email</label>
                      <input type="email" className="form-control" id="email" name="email" autoComplete="off" 
                      value={user.email}
                      onChange={handleInputs}
                      placeholder="Enter email" aria-describedby="emailHelp" />
                    </div>
                    {/* phone */}
                    <div className="mb-3">
                      <label htmlFor="phone" for="exampleInputEmail1" className="form-label"><i class="zmdi zmdi-phone-in-talk -add zmdi-hc-2x"></i>Phone Number</label>
                      <input type="number" className="form-control" id="phone" name="phone" autoComplete="off"
                      value={user.phone}
                      onChange={handleInputs}
                       placeholder="Enter phone " aria-describedby="emailHelp" />
                    </div>
                    {/* profession */}
                    <div className="mb-3">
                      <label htmlFor="profession" for="exampleInputEmail1" className="form-label"><i class="zmdi zmdi-slideshow -add zmdi-hc-2x"></i>Profession</label>
                      <input type="text" className="form-control" id="profession" name="work" autoComplete="off" 
                      value={user.work}
                      onChange={handleInputs}
                      placeholder="Enter student or teacher" aria-describedby="emailHelp" />
                    </div>
                    {/* password */}
                    <div className="mb-3">
                      <label htmlFor="password" for="exampleInputPassword1" className="form-label"><i class="zmdi zmdi-lock -add zmdi-hc-2x"></i>Password</label>
                      <input type="password" name="password" className="form-control" id="password"  
                      value={user.password}
                      onChange={handleInputs}
                      placeholder="Enter password"/>
                    </div>
                    {/* confirm password*/}
                    <div className="mb-3">
                      <label htmlFor="cpassword" for="exampleInputPassword1" className="form-label"><i class="zmdi zmdi-lock -add zmdi-hc-2x"></i>Confirm Password</label>
                      <input type="cpassword" name="cpassword" className="form-control" id="cpassword" 
                      value={user.cpassword}
                      onChange={handleInputs}
                       placeholder="Confirm your  Password"/>
                    </div>
                    <button type="submit" name="signup" id="signup" className="btn btn-outline-info" value="register" onClick={PostData}>Signup</button>
                    <Link to="/login"><button  className="btn btn-outline-success ms-5">Login</button> </Link> 
                 </form>
                
              </div>
          </div>
        </div>
      </section>
    
    </>
  )
}

export default Signup