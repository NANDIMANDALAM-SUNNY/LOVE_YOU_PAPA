import React from 'react'
import PropTypes from 'prop-types'
import { Link } from 'react-router-dom';
import { userContext } from '../App';
import { useContext } from 'react';
import exdemia from './images/exdemia.png';

export default function Navbar(props) {
    const { state, dispatch } = useContext(userContext);
    const RenderMenu = ()=>{
        if(state){
            return(
                <>
                  <nav className={"navbar navbar-expand-lg navbar-light bg-light "}>
            <div className="container-fluid">
                <Link className="navbar-brand" to="/"><img src={exdemia} alt="" style={{width:"50px"}}/> EXDEMIA</Link>
                <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul className="navbar-nav ms-auto mb-3  mb-lg-0">
                <li className="nav-item me-5">
                <Link className="nav-link" aria-current="page" to="/"><button class="btn btn-outline-primary">Home</button></Link>
            </li>

            <li className="nav-item me-5">
                <Link className="nav-link" aria-current="page" to="/about"><button class="btn btn-outline-secondary">About You</button></Link>
            </li>
            <li className="nav-item me-5">
                <Link className="nav-link" aria-current="page" to="/contact"><button class="btn btn-outline-warning">Contact us</button></Link>
            </li>

            <li className="nav-item me-5">
                <Link className="nav-link" aria-current="page" to="/mail"><button class="btn btn-outline-warning">Mail</button></Link>
            </li>
            {/* <li className="nav-item">
                <Link className="nav-link" aria-current="page" to="/login">Login</Link>
            </li>
            <li className="nav-item">
                <Link className="nav-link" aria-current="page" to="/signup">Sign Up</Link>
            </li> */}
            <li className="nav-item me-5">
                <Link className="nav-link " to="/logout"> <button class="btn btn-outline-danger">Logout</button></Link>
               
            </li>
            </ul>
                </div>
            </div>
        </nav>
            </>
            )
        }else{
            return(
                <>
                <nav className={"navbar navbar-expand-lg navbar-light bg-light "}>
            <div className="container-fluid">
                {/* <Link className="navbar-brand" to="#">EXDEMIA</Link> */}
                <h5><img src={exdemia} alt="" style={{width:"50px"}}/>EXDEMIA</h5>
                <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul className="navbar-nav ms-auto mb-3 mb-lg-0">
                                        {/* <li className="nav-item">
                            <Link className="nav-link" aria-current="page" to="/">Home</Link>
                        </li>

                        <li className="nav-item">
                            <Link className="nav-link" aria-current="page" to="/about">About</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" aria-current="page" to="/contact">Contact Us</Link>
                        </li> */}
                        <li className="nav-item me-5">
                            <Link className="nav-link" aria-current="page" to="/login"><button class="btn btn-outline-success">Login</button></Link>
                        </li>
                        <li className="nav-item me-5">
                            <Link className="nav-link" aria-current="page" to="/signup"><button class="btn btn-outline-info">Sign up</button></Link>
                        </li>
                        {/* <li className="nav-item">
                            <Link className="nav-link" to="/logout">Logout</Link>
                        </li> */}

</ul>
                </div>
            </div>
        </nav>
                </>
            )
        }
    }
    return (
        <>
        
                        <RenderMenu />
                    
        </>
    )
}

Navbar.propTypes = {
    title: PropTypes.string.isRequired,
    aboutText: PropTypes.string.isRequired
}

Navbar.defaultProps = {
    title: 'Set title here',
    aboutText: 'About'
  };