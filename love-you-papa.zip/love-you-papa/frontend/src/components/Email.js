import React from 'react';
import emailjs from 'emailjs-com';
const Email = () => {


  return (
    <form>
        <label htmlFor=""> name</label>
        <input type="text" name="name" />
        <label htmlFor=""> email</label>
        <input type="email" name="email" />
        <label htmlFor="">Message</label>
        <textarea name="" id="" cols="4" rows="4"></textarea>
        <button type="submit">submit</button>
    </form>
    // service_1ar1j64
  )
}

export default Email