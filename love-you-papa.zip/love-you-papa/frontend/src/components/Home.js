import {React,useState,useEffect} from 'react';
import logo from './images/licetlogo.png';


const Home = () => {

  const [userName,setUserName] = useState('');
  const [show ,setShow] = useState(false);
  


  
  
  const userHomePage = async () =>{
    try{
      const res =await fetch('/getdata',{
          method:"GET",
          headers:{
            "Content-Type":"application/json"
          },
      });
      const data = await res.json();
      console.log(data);
      setUserName(data.name);
      setShow(true);

      if(!res.status===200){
        const error = new Error (res.error);
        throw error;
      }
    }catch(err){
      console.log(err);
     

    }
  }
useEffect(() => {
  userHomePage();
}, [])






  return (
    <><p className='pt-5'>HOLA</p>
    <h1>{userName}</h1>
    <h3>{show ? "Welcome to licet portal":'PLease log in '}</h3>
    <img src={logo} alt="logo" />
    </>
  )
}

export default Home


// import React from 'react'
