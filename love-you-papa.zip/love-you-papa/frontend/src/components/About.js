import {React,useState,useEffect} from 'react'
import logo from './images/licetlogo.png';
import student from './images/student.gif';
import teacher from './images/teacher.gif';

const About = () => {
  const [userData,setUserData] = useState({});

  
  const callAboutPage = async () =>{
    try{
      const res =await fetch('/about',{
          method:"GET",
          headers:{
            Accept:"appllication/json",
            "Content-Type":"application/json"
          },
          credentials:"include"
      });
      const data = await res.json();
      console.log(data);
      setUserData(data);

      if(!res.status===200){
        const error = new Error (res.error);
        throw error;
      }
    }catch(err){
      console.log(err);
      

    }
  }
useEffect(() => {
  callAboutPage();
}, [])



  return (
   <>
   <div className="container">
     <form method="GET">
        <div className="row">
          {/* profile pic */}
          <div className="col-md-4">
            <img src={userData.work === 'student' ? student:teacher} alt="logo" style={{width:"250px"}} />
          </div>
         
          <div className="col-md-6">
            <div className="profileHead">
                <h1>{ userData.name}</h1>


               

            </div>
          </div>


            <div className="contain">
              <div className="tab-content" id='mytabcontent'>
                <div className="tab-panel fade show active" id="home " role="tabpanel" aria-labelledby="home" > 
                  <div className="row mt-5">
                    <div className="col-md-6 ">
                      <label htmlFor="">User Id</label>
                    </div>
                    <div className="col-md-6">
                      <p>{userData._id}</p>
                    </div>
                  </div>

                  <div className="row mt-3">
                    <div className="col-md-6 ">
                      <label htmlFor="">Name</label>
                    </div>
                    <div className="col-md-6">
                      <p>{userData.name}</p>
                    </div>
                  </div>

                  <div className="row mt-3">
                    <div className="col-md-6 ">
                      <label htmlFor="">Email</label>
                    </div>
                    <div className="col-md-6">
                      <p>{userData.email}</p>
                    </div>
                  </div>

                  <div className="row mt-3">
                    <div className="col-md-6 ">
                      <label htmlFor="">Profession</label>
                    </div>
                    <div className="col-md-6">
                      <p>{userData.work}</p>
                    </div>
                  </div>

                  <div className="row mt-3">
                    <div className="col-md-6 ">
                      <label htmlFor="">Phone Number</label>
                    </div>
                    <div className="col-md-6">
                      <p>{userData.phone}</p>
                    </div>
                  </div>

                </div>
              </div>
            </div>

        </div>
     </form>
   </div>
   
   </>
  )
}

export default About